# QWEN NEXUS 2.0 — Guest / No History

QWEN NEXUS adalah workspace AI tanpa login, tanpa Google OAuth, tanpa akun, tanpa database, dan tanpa penyimpanan riwayat chat.

## Fitur
- Langsung masuk sebagai guest.
- Chat dengan Workers AI melalui Cloudflare Worker.
- Tidak ada endpoint login, logout, riwayat chat, D1, atau R2.
- Riwayat percakapan hanya disimpan sementara di memori tab browser untuk konteks percakapan aktif. Reload/menutup tab menghapusnya.
- File teks/kode dapat dipilih dan dibaca lokal oleh browser lalu dimasukkan ke prompt. File tidak disimpan ke cloud. File biner hanya dikenali dari metadata; belum ditranskripsi/dianalisis kontennya.
- UI responsif untuk HP dan desktop.

## Deploy
1. Install Node.js dan jalankan `npm install`.
2. Pastikan akun Cloudflare memiliki akses Workers AI.
3. Jalankan `npx wrangler dev` untuk uji lokal.
4. Jalankan `npx wrangler deploy`.

`wrangler.toml` sudah memakai Workers AI binding dan tidak membutuhkan D1/R2/OAuth secret. Model default dapat diganti pada `AI_MODEL` sesuai model yang tersedia di akun/region Cloudflare.

## Catatan privasi
Aplikasi ini tidak membuat log chat atau menyimpan riwayat chat ke database. Pesan tetap dikirim ke Cloudflare Workers AI untuk menghasilkan jawaban, sehingga penyedia layanan AI memproses prompt sesuai ketentuan layanan mereka. Jangan kirim rahasia/password.
